import streamlit as st
import random
import math
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Import startup handler for robust initialization
try:
    from startup_handler import startup_handler
    startup_results = startup_handler.initialize_components()
    PLOTLY_AVAILABLE = startup_handler.plotly_available
    DATABASE_AVAILABLE = startup_handler.database_available
except Exception as e:
    st.error(f"Critical startup error: {str(e)}")
    PLOTLY_AVAILABLE = False
    DATABASE_AVAILABLE = False
    startup_results = {}

# Import plotting libraries with fallback
if PLOTLY_AVAILABLE:
    try:
        import plotly.graph_objects as go
        import plotly.express as px
    except ImportError:
        PLOTLY_AVAILABLE = False

if not PLOTLY_AVAILABLE:
    # Create mock objects to prevent errors
    class MockGO:
        class Figure:
            def __init__(self, *args, **kwargs):
                pass
            def add_trace(self, *args, **kwargs):
                pass
            def update_layout(self, *args, **kwargs):
                pass
        class Scatter:
            def __init__(self, *args, **kwargs):
                pass
        class Bar:
            def __init__(self, *args, **kwargs):
                pass
        class Pie:
            def __init__(self, *args, **kwargs):
                pass
    go = MockGO()
    px = MockGO()

# Import database wrapper with comprehensive error handling
if DATABASE_AVAILABLE:
    try:
        from database_wrapper import DatabaseWrapper
        db_wrapper = DatabaseWrapper()
    except ImportError as e:
        DATABASE_AVAILABLE = False
        db_wrapper = None

if not DATABASE_AVAILABLE:
    class MockDBWrapper:
        def is_available(self):
            return False
        def get_all_athletes(self):
            return []
        def create_athlete(self, *args, **kwargs):
            return None
        def save_training_week(self, *args, **kwargs):
            return None
        def save_training_session(self, *args, **kwargs):
            return None
        def get_athlete_progress(self, *args, **kwargs):
            return []
        def get_training_history(self, *args, **kwargs):
            return []
        def get_performance_analytics(self, *args, **kwargs):
            return pd.DataFrame()
    db_wrapper = MockDBWrapper()

@st.cache_resource
def init_database():
    """Initialize database with proper error handling and caching"""
    if DATABASE_AVAILABLE and db_wrapper:
        try:
            return db_wrapper.is_available
        except Exception as e:
            st.warning(f"Database initialization issue: {str(e)}")
            return False
    return False

def generate_speed_session():
    """
    Generate a speed session (phosphagen-dominant) comprised of short sprints.
    Allowed sprint distances are 30 m and 60 m.
    The total distance in the session does not exceed 300 m.
    """
    allowed_distances = [30, 60]
    session_runs = []
    total_distance = 0
    
    # Continue to add sprints until reaching near 300 m.
    while True:
        # Filter out distances that would not push total over the limit.
        possible = [d for d in allowed_distances if total_distance + d <= 300]
        if not possible:
            break
        run_distance = random.choice(possible)
        session_runs.append(run_distance)
        total_distance += run_distance
        # With a substantial total (e.g. 240 m or more), sometimes end early.
        if total_distance >= 240 and random.random() > 0.5:
            break
    return session_runs, total_distance

def generate_speed_endurance_session():
    """
    Generate a speed endurance session (glycolytic-dominant).
    The runs are longer and come in distances of 150 m or 250 m.
    Typically, one or two repetitions are performed.
    """
    allowed_distances = [150, 250]
    num_reps = random.choice([1, 2])
    session_runs = random.choices(allowed_distances, k=num_reps)
    total_distance = sum(session_runs)
    return session_runs, total_distance

def generate_oxidative_session():
    """
    Generate an oxidative energy session.
    This is a continuous low-intensity aerobic workout that aids recovery.
    Duration is chosen as either 30 or 40 minutes.
    """
    duration_minutes = random.choice([30, 40])
    return duration_minutes

def generate_strength_session():
    """
    Generate a strength training session focusing on explosive power.
    Includes concentric/eccentric emphasis and single leg exercises.
    """
    # Main compound movements with concentric/eccentric focus
    compound_exercises = [
        {"exercise": "Back Squat", "emphasis": random.choice(["Concentric", "Eccentric"])},
        {"exercise": "Deadlift", "emphasis": random.choice(["Concentric", "Eccentric"])},
        {"exercise": "Romanian Deadlift", "emphasis": random.choice(["Concentric", "Eccentric"])}
    ]
    
    # Single leg exercises for unilateral strength
    single_leg_exercises = [
        "Single Leg Squats (Pistol Squats)",
        "Bulgarian Split Squats",
        "Single Leg Romanian Deadlifts",
        "Single Leg Hip Thrusts",
        "Single Leg Glute Bridges"
    ]
    
    # Power/plyometric exercises
    power_exercises = [
        "Box Jumps",
        "Depth Jumps",
        "Single Leg Bounds",
        "Lateral Bounds",
        "Medicine Ball Slams"
    ]
    
    # Select exercises for the session
    main_exercise = random.choice(compound_exercises)
    selected_single_leg = random.sample(single_leg_exercises, 2)
    selected_power = random.sample(power_exercises, 2)
    
    return {
        "main_exercise": main_exercise,
        "single_leg_exercises": selected_single_leg,
        "power_exercises": selected_power,
        "sets_reps": "3-4 sets × 3-6 reps (strength focus)"
    }

def generate_assisted_resistance_sprint():
    """
    Generate assisted or resistance sprint training session.
    These modify sprint mechanics and force production.
    """
    session_type = random.choice(["Assisted Sprinting", "Resistance Sprinting"])
    
    if session_type == "Assisted Sprinting":
        methods = [
            "Downhill Sprints (2-3° decline)",
            "Elastic Cord Assistance",
            "Treadmill Overspeed Training"
        ]
        distances = [20, 30, 40]
        focus = "Overspeed training to improve stride frequency and neural drive"
        
    else:  # Resistance Sprinting
        methods = [
            "Sled Pulls (10-15% body weight)",
            "Parachute Sprints",
            "Uphill Sprints (3-5° incline)",
            "Weighted Vest Sprints (5-10% body weight)"
        ]
        distances = [20, 30, 40]
        focus = "Resistance training to improve stride power and force production"
    
    selected_method = random.choice(methods)
    selected_distances = random.sample(distances, random.randint(2, 3))
    total_reps = random.randint(4, 6)
    
    return {
        "session_type": session_type,
        "method": selected_method,
        "distances": selected_distances,
        "total_reps": total_reps,
        "focus": focus
    }

def generate_complex_training_session():
    """
    Generate a complex training session combining weight lifting and plyometrics 
    before and after sprinting. This explores the potentiation effects.
    """
    
    # Pre-sprint activation
    pre_sprint_weights = [
        "Heavy Back Squats (3-5 reps @ 85-90% 1RM)",
        "Heavy Deadlifts (3-5 reps @ 85-90% 1RM)", 
        "Heavy Bulgarian Split Squats (3-5 reps each leg)",
        "Heavy Trap Bar Deadlifts (3-5 reps @ 85-90% 1RM)"
    ]
    
    pre_sprint_plyos = [
        "Depth Jumps (3-5 reps)",
        "Single Leg Bounds (3-5 reps each)",
        "Reactive Box Jumps (3-5 reps)",
        "Medicine Ball Slams (3-5 reps)"
    ]
    
    # Post-sprint power development
    post_sprint_weights = [
        "Jump Squats (6-8 reps @ 30-40% 1RM)",
        "Speed Deadlifts (6-8 reps @ 40-50% 1RM)",
        "Single Leg Jump Squats (6-8 reps each)",
        "Explosive Romanian Deadlifts (6-8 reps @ 40% 1RM)"
    ]
    
    post_sprint_plyos = [
        "Tuck Jumps (6-8 reps)",
        "Lateral Bounds (6-8 reps each direction)",
        "Single Leg Hops (6-8 reps each)",
        "Broad Jumps (6-8 reps)"
    ]
    
    # Sprint component
    sprint_distances = [30, 40, 50, 60]
    sprint_reps = random.randint(3, 5)
    
    selected_pre_weight = random.choice(pre_sprint_weights)
    selected_pre_plyo = random.choice(pre_sprint_plyos)
    selected_sprint_distance = random.choice(sprint_distances)
    selected_post_weight = random.choice(post_sprint_weights)
    selected_post_plyo = random.choice(post_sprint_plyos)
    
    return {
        "pre_sprint_weight": selected_pre_weight,
        "pre_sprint_plyo": selected_pre_plyo,
        "sprint_distance": selected_sprint_distance,
        "sprint_reps": sprint_reps,
        "post_sprint_weight": selected_post_weight,
        "post_sprint_plyo": selected_post_plyo,
        "rest_between_sets": "3-4 minutes between each complex",
        "focus": "Post-activation potentiation and power development"
    }

def get_periodization_phase(week):
    """
    Determine training phase based on 16-week periodization model.
    Returns phase info with volume/intensity characteristics.
    """
    if week <= 4:
        return {
            "phase": "Base Building",
            "volume": "High",
            "intensity": "Low-Moderate",
            "focus": "General fitness, aerobic capacity, movement patterns",
            "recovery": "Standard",
            "volume_modifier": 1.2,
            "intensity_modifier": 0.8
        }
    elif week <= 8:
        return {
            "phase": "Strength Development",
            "volume": "Moderate-High",
            "intensity": "Moderate",
            "focus": "Maximum strength, power development, technique refinement",
            "recovery": "Increased",
            "volume_modifier": 1.0,
            "intensity_modifier": 0.9
        }
    elif week <= 12:
        return {
            "phase": "Speed Development",
            "volume": "Moderate",
            "intensity": "High",
            "focus": "Maximum velocity, acceleration, speed endurance",
            "recovery": "High priority",
            "volume_modifier": 0.8,
            "intensity_modifier": 1.1
        }
    else:  # weeks 13-16
        return {
            "phase": "Pre-Competition",
            "volume": "Low",
            "intensity": "Very High",
            "focus": "Race preparation, peak performance, competition simulation",
            "recovery": "Maximum",
            "volume_modifier": 0.6,
            "intensity_modifier": 1.2
        }

def adjust_session_for_periodization(session_type, week):
    """
    Adjust training session based on periodization phase.
    """
    phase_info = get_periodization_phase(week)
    volume_mod = phase_info["volume_modifier"]
    intensity_mod = phase_info["intensity_modifier"]
    
    if session_type == "speed":
        # Adjust total distance based on volume modifier
        max_distance = int(300 * volume_mod)
        return max_distance, phase_info
    elif session_type == "strength":
        # Adjust sets/reps based on phase
        if week <= 4:
            sets_reps = "3-4 sets × 8-12 reps (hypertrophy focus)"
        elif week <= 8:
            sets_reps = "4-5 sets × 3-6 reps (strength focus)"
        elif week <= 12:
            sets_reps = "3-4 sets × 1-3 reps (power focus)"
        else:
            sets_reps = "2-3 sets × 1-3 reps (peak power)"
        return sets_reps, phase_info
    elif session_type == "endurance":
        # Adjust repetitions based on phase
        if week <= 8:
            max_reps = 3
        elif week <= 12:
            max_reps = 2
        else:
            max_reps = 1
        return max_reps, phase_info
    
    return 0, phase_info

# Define weekly schedule structure
weekly_schedule = {
    "Monday":    {"session": "Speed Session (Phosphagen)", "function": generate_speed_session},
    "Tuesday":   {"session": "Complex Training (Weights + Plyos + Sprints)", "function": generate_complex_training_session},
    "Wednesday": {"session": "Assisted/Resistance Sprints", "function": generate_assisted_resistance_sprint},
    "Thursday":  {"session": "Speed Endurance Session (Glycolytic)", "function": generate_speed_endurance_session},
    "Friday":    {"session": "Strength Training", "function": generate_strength_session},
    "Saturday":  {"session": "Oxidative Training (Aerobic Recovery)", "function": generate_oxidative_session},
    "Sunday":    {"session": "Rest & Recovery", "function": lambda: None}
}

def create_sample_data():
    """Create sample data for demonstration"""
    # Generate sample progress data
    weeks = list(range(1, 17))
    sprint_100m_times = [10.5 + random.uniform(-0.3, 0.1) - (week * 0.02) for week in weeks]
    sprint_200m_times = [21.2 + random.uniform(-0.5, 0.2) - (week * 0.04) for week in weeks]
    max_squats = [120 + (week * 2.5) + random.uniform(-5, 5) for week in weeks]
    vertical_jumps = [65 + (week * 0.8) + random.uniform(-2, 2) for week in weeks]
    
    return pd.DataFrame({
        'week': weeks,
        'sprint_100m': sprint_100m_times,
        'sprint_200m': sprint_200m_times,
        'max_squat': max_squats,
        'vertical_jump': vertical_jumps
    })

def create_performance_chart(df):
    """Create sprint performance progress chart"""
    if PLOTLY_AVAILABLE:
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=df['week'],
            y=df['sprint_100m'],
            mode='lines+markers',
            name='100m Sprint Time',
            line=dict(color='#FF6B6B', width=3),
            marker=dict(size=8)
        ))
        
        fig.add_trace(go.Scatter(
            x=df['week'],
            y=df['sprint_200m'],
            mode='lines+markers',
            name='200m Sprint Time',
            line=dict(color='#4ECDC4', width=3),
            marker=dict(size=8),
            yaxis='y2'
        ))
        
        fig.update_layout(
            title='Sprint Performance Progress Over 16 Weeks',
            xaxis_title='Training Week',
            yaxis=dict(
                title='100m Time (seconds)',
                title_font=dict(color='#FF6B6B'),
                tickfont=dict(color='#FF6B6B')
            ),
            yaxis2=dict(
                title='200m Time (seconds)',
                title_font=dict(color='#4ECDC4'),
                tickfont=dict(color='#4ECDC4'),
                anchor='x',
                overlaying='y',
                side='right'
            ),
            height=400,
            showlegend=True,
            hovermode='x unified'
        )
        
        return fig
    else:
        return None

def create_strength_chart(df):
    """Create strength progress chart"""
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=df['week'],
        y=df['max_squat'],
        name='Max Squat (kg)',
        marker_color='#45B7D1',
        opacity=0.8
    ))
    
    fig.add_trace(go.Scatter(
        x=df['week'],
        y=df['vertical_jump'],
        mode='lines+markers',
        name='Vertical Jump (cm)',
        line=dict(color='#96CEB4', width=3),
        marker=dict(size=10),
        yaxis='y2'
    ))
    
    fig.update_layout(
        title='Strength and Power Development',
        xaxis_title='Training Week',
        yaxis=dict(
            title=dict(text='Max Squat (kg)', font=dict(color='#45B7D1')),
        ),
        yaxis2=dict(
            title=dict(text='Vertical Jump (cm)', font=dict(color='#96CEB4')),
            anchor='x',
            overlaying='y',
            side='right'
        ),
        height=400,
        showlegend=True
    )
    
    return fig

def create_periodization_chart():
    """Create periodization phase visualization"""
    phases = ['Base Building', 'Strength Development', 'Speed Development', 'Pre-Competition']
    weeks = [4, 4, 4, 4]
    colors = ['#FFE66D', '#FF6B6B', '#4ECDC4', '#95E1D3']
    
    fig = go.Figure(data=[go.Bar(
        x=phases,
        y=weeks,
        marker_color=colors,
        text=[f'{w} weeks' for w in weeks],
        textposition='inside',
        textfont=dict(size=14, color='white')
    )])
    
    fig.update_layout(
        title='16-Week Periodization Structure',
        xaxis_title='Training Phase',
        yaxis_title='Duration (Weeks)',
        height=300,
        showlegend=False
    )
    
    return fig

def create_volume_intensity_chart():
    """Create volume vs intensity chart across phases"""
    weeks = list(range(1, 17))
    volume = [100] * 4 + [80] * 4 + [60] * 4 + [40] * 4  # Decreasing volume
    intensity = [60] * 4 + [70] * 4 + [85] * 4 + [95] * 4  # Increasing intensity
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=weeks,
        y=volume,
        mode='lines+markers',
        name='Training Volume',
        line=dict(color='#FF9999', width=3),
        fill='tonexty'
    ))
    
    fig.add_trace(go.Scatter(
        x=weeks,
        y=intensity,
        mode='lines+markers',
        name='Training Intensity',
        line=dict(color='#66B2FF', width=3),
        fill='tozeroy'
    ))
    
    # Add phase dividers
    if PLOTLY_AVAILABLE:
        try:
            for week in [4, 8, 12]:
                fig.add_vline(x=week + 0.5, line_dash="dash", line_color="gray")
        except AttributeError:
            # Fallback if add_vline not available
            pass
    
    fig.update_layout(
        title='Training Volume vs Intensity Balance',
        xaxis_title='Training Week',
        yaxis_title='Relative Percentage (%)',
        height=400,
        showlegend=True
    )
    
    return fig

def create_session_distribution_chart():
    """Create training session type distribution"""
    session_types = ['Speed Sessions', 'Complex Training', 'Assisted/Resistance', 'Speed Endurance', 'Strength Training', 'Oxidative', 'Rest Days']
    counts = [2, 1, 1, 1, 1, 1, 1]
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#A0A0A0']
    
    if PLOTLY_AVAILABLE:
        fig = go.Figure(data=[go.Pie(
            labels=session_types,
            values=counts,
            hole=0.3,
            marker_colors=colors
        )])
        
        fig.update_layout(
            title='Weekly Training Session Distribution',
            height=400,
            showlegend=True
        )
    else:
        # Create mock figure for fallback
        fig = go.Figure()
    
    return fig

def main():
    try:
        st.set_page_config(
            page_title="Olympic Sprinter Training Schedule",
            page_icon="🏃‍♂️",
            layout="wide"
        )
        
        # Display startup status if available
        if startup_results:
            status_message = startup_handler.get_status_message(startup_results)
            if "✅" in status_message:
                st.success(status_message)
            elif "ℹ️" in status_message:
                st.info(status_message)
            else:
                st.warning(status_message)
        
        # Initialize database with error handling
        try:
            with st.spinner("Finalizing application setup..."):
                db_status = init_database()
        except Exception as db_error:
            st.warning(f"Database setup encountered issues: {str(db_error)}")
            db_status = False
            
    except Exception as e:
        error_msg = startup_handler.handle_startup_error(e) if 'startup_handler' in globals() else f"Application error: {str(e)}"
        st.error(error_msg)
        st.info("Continuing in limited functionality mode...")
        db_status = False
    
    st.title("🏃‍♂️ Olympic Sprinter Training Schedule Generator")
    st.subheader("16-Week Periodized Training Plans for 100m/200m Sprinters")
    
    # Introduction and explanation
    st.markdown("""
    This application generates weekly training schedules for Olympic 100m/200m sprinters based on 
    **16-week periodization** leading to pre-competitive season. The key to effective speed training 
    is finding the right balance between **volume and intensity** along with proper **periodization and recovery**.
    """)
    
    # Add week selector
    st.markdown("### 📅 Select Training Week")
    col1, col2 = st.columns([1, 3])
    
    with col1:
        selected_week = st.selectbox(
            "Training Week:",
            options=list(range(1, 17)),
            index=0,
            help="Select which week of the 16-week periodization cycle"
        )
    
    with col2:
        phase_info = get_periodization_phase(selected_week)
        st.info(f"**Week {selected_week}**: {phase_info['phase']} | Volume: {phase_info['volume']} | Intensity: {phase_info['intensity']}")
    
    st.divider()
    
    # Energy Systems and Training Methods Explanation
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.markdown("### ⚡ Phosphagen System")
        st.markdown("""
        **Focus:** Explosive power and acceleration
        - **Sessions:** Monday
        - **Distance:** 30m and 60m sprints
        - **Total Volume:** ≤300m per session
        - **Purpose:** Maximum speed development
        """)
    
    with col2:
        st.markdown("### 🔥 Glycolytic System")
        st.markdown("""
        **Focus:** Speed endurance and lactate tolerance
        - **Sessions:** Thursday
        - **Distance:** 150m and 250m sprints
        - **Repetitions:** 1-2 per session
        - **Purpose:** Maintaining near-maximal speeds
        """)
    
    with col3:
        st.markdown("### 🔗 Complex Training")
        st.markdown("""
        **Focus:** Weight + Plyos + Sprints combination
        - **Sessions:** Tuesday
        - **Methods:** PAP and post-sprint power
        - **Purpose:** Explore potentiation effects
        - **Benefit:** Enhanced neuromuscular power
        """)
    
    with col4:
        st.markdown("### 🏃 Assisted/Resistance")
        st.markdown("""
        **Focus:** Sprint mechanics enhancement
        - **Sessions:** Wednesday
        - **Methods:** Sled pulls, overspeed training
        - **Purpose:** Improve stride power/frequency
        - **Benefit:** Enhanced force production
        """)
    
    with col5:
        st.markdown("### 💪 Strength Training")
        st.markdown("""
        **Focus:** Power development and single-leg strength
        - **Sessions:** Friday
        - **Methods:** Concentric/Eccentric emphasis
        - **Focus:** Unilateral leg exercises
        - **Purpose:** Explosive force production
        """)
    
    st.divider()
    
    # Generate new schedule button
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("🔄 Generate New Training Schedule", type="primary", use_container_width=True):
            st.session_state.schedule_generated = True
            st.session_state.selected_week = selected_week
        
        # Initialize session state
        if 'schedule_generated' not in st.session_state:
            st.session_state.schedule_generated = True
            st.session_state.selected_week = selected_week
    
    if st.session_state.schedule_generated:
        current_week = st.session_state.selected_week
        current_phase = get_periodization_phase(current_week)
        
        st.markdown(f"## 📅 Week {current_week} Training Schedule")
        st.markdown(f"**Phase:** {current_phase['phase']} | **Focus:** {current_phase['focus']}")
        
        # Generate and display the weekly schedule
        days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        
        for day in days_order:
            details = weekly_schedule[day]
            session_type = details["session"]
            session_func = details["function"]
            
            # Adjust session based on periodization
            if "Speed Session" in session_type:
                max_dist, phase_info = adjust_session_for_periodization("speed", current_week)
                # Generate speed session with adjusted volume
                if isinstance(max_dist, int):
                    allowed_distances = [30, 60]
                    session_runs = []
                    total_distance = 0
                    
                    while total_distance < max_dist:
                        possible = [d for d in allowed_distances if total_distance + d <= max_dist]
                        if not possible:
                            break
                        run_distance = random.choice(possible)
                        session_runs.append(run_distance)
                        total_distance += run_distance
                        if total_distance >= max_dist * 0.8 and random.random() > 0.5:
                            break
                    result = (session_runs, total_distance)
                else:
                    result = generate_speed_session()
                
            elif "Strength Training" in session_type:
                sets_reps, phase_info = adjust_session_for_periodization("strength", current_week)
                # Generate strength session with adjusted sets/reps
                compound_exercises = [
                    {"exercise": "Back Squat", "emphasis": random.choice(["Concentric", "Eccentric"])},
                    {"exercise": "Deadlift", "emphasis": random.choice(["Concentric", "Eccentric"])},
                    {"exercise": "Romanian Deadlift", "emphasis": random.choice(["Concentric", "Eccentric"])}
                ]
                
                single_leg_exercises = [
                    "Single Leg Squats (Pistol Squats)",
                    "Bulgarian Split Squats",
                    "Single Leg Romanian Deadlifts",
                    "Single Leg Hip Thrusts",
                    "Single Leg Glute Bridges"
                ]
                
                power_exercises = [
                    "Box Jumps",
                    "Depth Jumps",
                    "Single Leg Bounds",
                    "Lateral Bounds",
                    "Medicine Ball Slams"
                ]
                
                main_exercise = random.choice(compound_exercises)
                selected_single_leg = random.sample(single_leg_exercises, 2)
                selected_power = random.sample(power_exercises, 2)
                
                result = {
                    "main_exercise": main_exercise,
                    "single_leg_exercises": selected_single_leg,
                    "power_exercises": selected_power,
                    "sets_reps": sets_reps
                }
                
            elif "Speed Endurance" in session_type:
                max_reps, phase_info = adjust_session_for_periodization("endurance", current_week)
                # Generate speed endurance session with adjusted reps
                allowed_distances = [150, 250]
                if isinstance(max_reps, int):
                    num_reps = min(random.choice([1, 2]), max_reps)
                else:
                    num_reps = random.choice([1, 2])
                session_runs = random.choices(allowed_distances, k=num_reps)
                total_distance = sum(session_runs)
                result = (session_runs, total_distance)
                
            elif "Complex Training" in session_type:
                result = session_func()
                
            else:
                result = session_func()
            
            # Create container for each day
            with st.container():
                col1, col2 = st.columns([1, 3])
                
                with col1:
                    st.markdown(f"### {day}")
                
                with col2:
                    if "Speed Session" in session_type:
                        st.markdown(f"**{session_type}**")
                        runs, total = result
                        
                        # Display sprint details
                        st.markdown(f"**Sprint Repetitions:** {' + '.join(map(str, runs))}m")
                        st.markdown(f"**Total Distance:** {total}m")
                        if isinstance(total, int):
                            st.markdown(f"**Periodization Adjustment:** Volume adjusted to {int((total/300)*100)}% of base volume")
                        else:
                            st.markdown("**Periodization Adjustment:** Training volume adjusted for current phase")
                        st.markdown("🎯 *Focus: Explosive starting speed using the phosphagen system*")
                        
                        # Show individual runs in a more visual way
                        run_display = []
                        for i, distance in enumerate(runs, 1):
                            run_display.append(f"Rep {i}: {distance}m")
                        st.info(" • ".join(run_display))
                        
                    elif "Speed Endurance" in session_type:
                        st.markdown(f"**{session_type}**")
                        runs, total = result
                        
                        st.markdown(f"**Sprint Repetitions:** {' + '.join(map(str, runs))}m")
                        st.markdown(f"**Total Distance:** {total}m")
                        st.markdown("🎯 *Focus: Sustained near-maximal speed (glycolytic energy) and recovery under fatigue*")
                        
                        # Show individual runs
                        run_display = []
                        for i, distance in enumerate(runs, 1):
                            run_display.append(f"Rep {i}: {distance}m")
                        st.warning(" • ".join(run_display))
                        
                    elif "Strength Training" in session_type:
                        st.markdown(f"**{session_type}**")
                        
                        # Display main compound exercise
                        main_ex = result["main_exercise"]
                        st.markdown(f"**Main Exercise:** {main_ex['exercise']} ({main_ex['emphasis']} Emphasis)")
                        st.markdown(f"**Sets/Reps:** {result['sets_reps']}")
                        
                        # Single leg exercises
                        st.markdown("**Single Leg Exercises:**")
                        for exercise in result["single_leg_exercises"]:
                            st.markdown(f"• {exercise}")
                        
                        # Power/plyometric exercises
                        st.markdown("**Power/Plyometric Exercises:**")
                        for exercise in result["power_exercises"]:
                            st.markdown(f"• {exercise}")
                        
                        st.markdown("🎯 *Focus: Explosive power development with unilateral strength emphasis*")
                        st.success(f"Strength session with {main_ex['emphasis'].lower()} emphasis and single-leg focus")
                        
                    elif "Complex Training" in session_type:
                        st.markdown(f"**{session_type}**")
                        
                        # Display the complex training sequence
                        st.markdown("**Training Sequence:**")
                        
                        # Pre-sprint activation
                        st.markdown("**1. Pre-Sprint Activation (PAP):**")
                        st.markdown(f"• **Heavy Lift:** {result['pre_sprint_weight']}")
                        st.markdown(f"• **Plyometric:** {result['pre_sprint_plyo']}")
                        
                        # Sprint component
                        st.markdown("**2. Sprint Component:**")
                        st.markdown(f"• **Distance:** {result['sprint_distance']}m")
                        st.markdown(f"• **Repetitions:** {result['sprint_reps']} sprints")
                        
                        # Post-sprint power development
                        st.markdown("**3. Post-Sprint Power Development:**")
                        st.markdown(f"• **Speed Lift:** {result['post_sprint_weight']}")
                        st.markdown(f"• **Reactive Plyometric:** {result['post_sprint_plyo']}")
                        
                        st.markdown(f"**Rest:** {result['rest_between_sets']}")
                        st.markdown(f"🎯 *{result['focus']}*")
                        
                        st.info("Complex training explores the combination of weights + plyos before and after sprinting for enhanced performance")
                        
                    elif "Assisted/Resistance" in session_type:
                        st.markdown(f"**{session_type}**")
                        
                        st.markdown(f"**Method:** {result['method']}")
                        st.markdown(f"**Type:** {result['session_type']}")
                        st.markdown(f"**Distances:** {', '.join(map(str, result['distances']))}m")
                        st.markdown(f"**Total Repetitions:** {result['total_reps']}")
                        st.markdown(f"🎯 *{result['focus']}*")
                        
                        # Color coding based on session type
                        if result['session_type'] == "Assisted Sprinting":
                            st.info(f"Overspeed training: {result['method']} for {result['total_reps']} reps")
                        else:
                            st.warning(f"Resistance training: {result['method']} for {result['total_reps']} reps")
                        
                    elif "Oxidative" in session_type:
                        st.markdown(f"**{session_type}**")
                        duration = result
                        
                        st.markdown(f"**Duration:** {duration} minutes continuous aerobic work")
                        st.markdown("🎯 *Focus: Improving oxygen uptake, recovery, and aerobic capacity*")
                        st.success(f"Continuous low-intensity training for {duration} minutes")
                        
                    else:  # Rest day
                        st.markdown(f"**{session_type}**")
                        st.markdown("🎯 *Complete rest and recovery*")
                        st.markdown("🛌 Take the day off to allow your body to recover and adapt to training")
                        st.info("Enjoy your rest day! Focus on nutrition, hydration, and sleep.")
                
                st.divider()
        
        # Training notes and tips
        st.markdown("## 📝 Training Notes")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🏃‍♂️ Training Tips")
            st.markdown("""
            - **Warm-up:** Always include a thorough warm-up before sprint sessions
            - **Recovery:** Allow full recovery between sprint repetitions
            - **Technique:** Focus on sprint mechanics during speed sessions
            - **Intensity:** Speed sessions should be at maximum effort (95-100%)
            - **Single Leg Focus:** Emphasize unilateral strength for sprint asymmetries
            - **Concentric/Eccentric:** Vary lifting tempo for power development
            """)
        
        with col2:
            st.markdown("### ⚠️ Important Reminders")
            st.markdown("""
            - **Progressive Loading:** Gradually increase training loads over time
            - **Resistance Training:** Start with lighter loads for sled/parachute work
            - **Assisted Sprints:** Focus on maintaining proper form at higher speeds
            - **Recovery Monitoring:** Pay attention to fatigue and recovery markers
            - **Strength Balance:** Address left/right leg strength imbalances
            - **Sleep:** Ensure adequate sleep for recovery and adaptation
            """)
        
        # Weekly summary
        st.markdown("## 📊 Weekly Training Summary")
        
        # Calculate totals
        total_speed_sessions = 2
        total_speed_endurance_sessions = 1
        total_strength_sessions = 1
        total_assisted_resistance_sessions = 1
        total_oxidative_sessions = 1
        total_rest_days = 1
        
        summary_cols = st.columns(3)
        
        with summary_cols[0]:
            st.metric("Speed Sessions", total_speed_sessions, "Phosphagen Focus")
            st.metric("Speed Endurance", total_speed_endurance_sessions, "Glycolytic Focus")
        
        with summary_cols[1]:
            st.metric("Strength Training", total_strength_sessions, "Power Development")
            st.metric("Assisted/Resistance", total_assisted_resistance_sessions, "Mechanics Enhancement")
        
        with summary_cols[2]:
            st.metric("Oxidative Sessions", total_oxidative_sessions, "Recovery Focus")
            st.metric("Rest Days", total_rest_days, "Complete Recovery")
            
        # Add 16-week periodization overview
        st.markdown("## 📊 16-Week Periodization Overview")
        st.markdown("""
        **Key Principle:** It takes 16 weeks of training to get ready for the pre-competitive season. 
        Finding the right balance between **volume and intensity** along with **periodization and recovery** 
        are the keys to effective speed training.
        """)
        
        # Periodization phases visualization
        phase_cols = st.columns(4)
        
        with phase_cols[0]:
            st.markdown("### 🏗️ Base Building")
            st.markdown("**Weeks 1-4**")
            st.markdown("""
            - **Volume:** High
            - **Intensity:** Low-Moderate
            - **Focus:** General fitness, movement patterns
            - **Recovery:** Standard
            """)
        
        with phase_cols[1]:
            st.markdown("### 💪 Strength Development")
            st.markdown("**Weeks 5-8**")
            st.markdown("""
            - **Volume:** Moderate-High
            - **Intensity:** Moderate
            - **Focus:** Maximum strength, power
            - **Recovery:** Increased
            """)
        
        with phase_cols[2]:
            st.markdown("### ⚡ Speed Development")
            st.markdown("**Weeks 9-12**")
            st.markdown("""
            - **Volume:** Moderate
            - **Intensity:** High
            - **Focus:** Maximum velocity, acceleration
            - **Recovery:** High priority
            """)
        
        with phase_cols[3]:
            st.markdown("### 🏆 Pre-Competition")
            st.markdown("**Weeks 13-16**")
            st.markdown("""
            - **Volume:** Low
            - **Intensity:** Very High
            - **Focus:** Race preparation, peak performance
            - **Recovery:** Maximum
            """)
        
        st.divider()
        
        # Add analytics and charts section
        st.markdown("## 📊 Performance Analytics & Visualizations")
        
        # Create sample data for demonstration
        sample_data = create_sample_data()
        
        # Performance charts
        chart_cols = st.columns(2)
        
        with chart_cols[0]:
            st.markdown("**Sprint Performance Progress**")
            if PLOTLY_AVAILABLE:
                fig = create_performance_chart(sample_data)
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            else:
                # Use Streamlit's built-in line chart
                sprint_data = sample_data[['week', 'sprint_100m', 'sprint_200m']].set_index('week')
                st.line_chart(sprint_data)
        
        with chart_cols[1]:
            st.markdown("**Strength and Power Development**")
            if PLOTLY_AVAILABLE:
                fig = create_strength_chart(sample_data)
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            else:
                # Use Streamlit's built-in charts
                strength_data = sample_data[['week', 'max_squat']].set_index('week')
                st.bar_chart(strength_data)
                jump_data = sample_data[['week', 'vertical_jump']].set_index('week')
                st.line_chart(jump_data)
        
        # Training structure visualizations
        structure_cols = st.columns(2)
        
        with structure_cols[0]:
            st.markdown("**16-Week Periodization Structure**")
            if PLOTLY_AVAILABLE:
                fig = create_periodization_chart()
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            else:
                # Simple bar chart for phases
                phase_data = pd.DataFrame({
                    'Phase': ['Base Building', 'Strength Development', 'Speed Development', 'Pre-Competition'],
                    'Weeks': [4, 4, 4, 4]
                })
                st.bar_chart(phase_data.set_index('Phase'))
        
        with structure_cols[1]:
            st.markdown("**Weekly Training Session Distribution**")
            session_data = pd.DataFrame({
                'Session Type': ['Speed Sessions', 'Complex Training', 'Assisted/Resistance', 'Speed Endurance', 'Strength Training', 'Oxidative', 'Rest Days'],
                'Count': [2, 1, 1, 1, 1, 1, 1]
            })
            st.bar_chart(session_data.set_index('Session Type'))
        
        # Volume vs Intensity analysis
        st.markdown("**Training Volume vs Intensity Balance**")
        if PLOTLY_AVAILABLE:
            fig = create_volume_intensity_chart()
            if fig:
                st.plotly_chart(fig, use_container_width=True)
        else:
            # Create volume vs intensity data
            weeks = list(range(1, 17))
            volume_intensity_data = pd.DataFrame({
                'Week': weeks,
                'Volume': [100] * 4 + [80] * 4 + [60] * 4 + [40] * 4,
                'Intensity': [60] * 4 + [70] * 4 + [85] * 4 + [95] * 4
            })
            st.line_chart(volume_intensity_data.set_index('Week'))
        
        # Performance metrics table
        st.markdown("### 📈 Performance Metrics Summary")
        metrics_cols = st.columns(4)
        
        with metrics_cols[0]:
            improvement_100m = sample_data['sprint_100m'].iloc[0] - sample_data['sprint_100m'].iloc[-1]
            st.metric("100m Improvement", f"{improvement_100m:.2f}s", delta=f"-{improvement_100m:.2f}s")
        
        with metrics_cols[1]:
            improvement_200m = sample_data['sprint_200m'].iloc[0] - sample_data['sprint_200m'].iloc[-1]
            st.metric("200m Improvement", f"{improvement_200m:.2f}s", delta=f"-{improvement_200m:.2f}s")
        
        with metrics_cols[2]:
            squat_gain = sample_data['max_squat'].iloc[-1] - sample_data['max_squat'].iloc[0]
            st.metric("Squat Strength Gain", f"{squat_gain:.0f}kg", delta=f"+{squat_gain:.0f}kg")
        
        with metrics_cols[3]:
            jump_gain = sample_data['vertical_jump'].iloc[-1] - sample_data['vertical_jump'].iloc[0]
            st.metric("Vertical Jump Gain", f"{jump_gain:.0f}cm", delta=f"+{jump_gain:.0f}cm")
        
        st.divider()
        
        # Add advanced training concepts explanation
        st.markdown("## 🔬 Advanced Training Concepts")
        
        concept_cols = st.columns(3)
        
        with concept_cols[0]:
            st.markdown("### 💪 Concentric vs Eccentric Training")
            st.markdown("""
            **Concentric (Shortening) Phase:**
            - Focus on explosive, rapid muscle contractions
            - Builds power and speed of movement
            - Used for developing acceleration mechanics
            
            **Eccentric (Lengthening) Phase:**
            - Controlled muscle lengthening under tension
            - Builds strength and muscle control
            - Critical for deceleration and injury prevention
            """)
            
            st.markdown("### 🦵 Single Leg Training Benefits")
            st.markdown("""
            - **Addresses Imbalances:** Corrects left/right leg strength differences
            - **Unilateral Power:** Develops independent leg strength and coordination
            - **Sprint Specificity:** Mimics single-leg nature of sprinting mechanics
            - **Stability Enhancement:** Improves core and hip stability during running
            """)
        
        with concept_cols[1]:
            st.markdown("### 🏃 Assisted Sprint Training")
            st.markdown("""
            **Methods and Benefits:**
            - **Downhill Sprints:** Natural overspeed from gravity assistance
            - **Elastic Cord Assistance:** Mechanical pull for higher stride frequency
            - **Treadmill Overspeed:** Controlled environment for technique work
            - **Neural Adaptation:** Trains nervous system for higher movement speeds
            """)
            
            st.markdown("### 🏋️ Resistance Sprint Training")
            st.markdown("""
            **Methods and Benefits:**
            - **Sled Pulls:** Horizontal force development and power
            - **Parachute Sprints:** Variable resistance throughout sprint
            - **Uphill Sprints:** Natural resistance from gravity
            - **Weighted Vests:** Added load for strength-speed development
            """)
        
        with concept_cols[2]:
            st.markdown("### 🔗 Complex Training Methodology")
            st.markdown("""
            **Key Principle:** The combination of weight lifting and plyometrics before and after sprinting must be explored for optimal power development.
            
            **Pre-Sprint Sequence (PAP):**
            - Heavy lifting (85-90% 1RM) for neural activation
            - Plyometrics for explosive readiness
            - Enhanced sprint performance through potentiation
            
            **Post-Sprint Sequence:**
            - Speed lifting (30-50% 1RM) for power development
            - Reactive plyometrics for neuromuscular adaptation
            - Builds on the sprint stimulus for enhanced adaptation
            
            **Benefits:**
            - Maximizes post-activation potentiation effects
            - Develops sport-specific power transfer
            - Enhances neuromuscular coordination
            - Improves force production at high velocities
            """)

if __name__ == "__main__":
    # Configure for deployment
    import os
    os.environ.setdefault('STREAMLIT_SERVER_HEADLESS', 'true')
    os.environ.setdefault('STREAMLIT_SERVER_ADDRESS', '0.0.0.0')
    os.environ.setdefault('STREAMLIT_SERVER_PORT', '5000')
    main()
