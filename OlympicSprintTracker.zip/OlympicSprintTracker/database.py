import os
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import json
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global variables for lazy initialization
engine = None
SessionLocal = None
Base = declarative_base()
_db_initialized = False

def get_database_engine():
    """Get database engine with proper error handling and lazy initialization"""
    global engine, SessionLocal
    
    if engine is not None:
        return engine, SessionLocal
    
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        
        if DATABASE_URL:
            logger.info("Connecting to PostgreSQL database...")
            # Add connection pooling and error handling for PostgreSQL
            engine = create_engine(
                DATABASE_URL,
                pool_pre_ping=True,
                pool_recycle=300,
                connect_args={
                    "connect_timeout": 10,
                    "application_name": "sprint_training_app"
                }
            )
            # Test connection
            with engine.connect() as conn:
                conn.execute(text("SELECT 1")).fetchone()
            logger.info("PostgreSQL connection established successfully")
        else:
            logger.info("No DATABASE_URL found, using SQLite fallback...")
            # Use SQLite as fallback with proper error handling
            engine = create_engine(
                'sqlite:///./training_data.db',
                pool_pre_ping=True,
                connect_args={"check_same_thread": False}
            )
            logger.info("SQLite database initialized successfully")
        
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        return engine, SessionLocal
        
    except Exception as e:
        logger.error(f"Database connection failed: {str(e)}")
        logger.info("Falling back to in-memory SQLite database...")
        
        # Ultimate fallback to in-memory SQLite
        try:
            engine = create_engine(
                'sqlite:///:memory:',
                connect_args={"check_same_thread": False}
            )
            SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
            logger.info("In-memory SQLite database initialized as fallback")
            return engine, SessionLocal
        except Exception as fallback_error:
            logger.error(f"Even fallback database failed: {str(fallback_error)}")
            raise Exception("Unable to initialize any database connection")

# Database Models
class Athlete(Base):
    __tablename__ = "athletes"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True)
    age = Column(Integer)
    weight = Column(Float)  # in kg
    height = Column(Float)  # in cm
    personal_best_100m = Column(Float)  # in seconds
    personal_best_200m = Column(Float)  # in seconds
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

class TrainingWeek(Base):
    __tablename__ = "training_weeks"
    
    id = Column(Integer, primary_key=True, index=True)
    athlete_id = Column(Integer, nullable=False)
    week_number = Column(Integer, nullable=False)  # 1-16 periodization cycle
    phase = Column(String, nullable=False)  # Base Building, Strength Development, etc.
    generated_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text)

class TrainingSession(Base):
    __tablename__ = "training_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    week_id = Column(Integer, nullable=False)
    day_of_week = Column(String, nullable=False)  # Monday, Tuesday, etc.
    session_type = Column(String, nullable=False)  # Speed Session, Complex Training, etc.
    session_data = Column(Text)  # JSON string of session details
    completed = Column(Boolean, default=False)
    completion_date = Column(DateTime)
    performance_notes = Column(Text)
    perceived_exertion = Column(Integer)  # 1-10 scale

class PerformanceMetrics(Base):
    __tablename__ = "performance_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    athlete_id = Column(Integer, nullable=False)
    session_id = Column(Integer, nullable=False)
    metric_type = Column(String, nullable=False)  # sprint_time, distance, repetitions
    value = Column(Float, nullable=False)
    unit = Column(String)  # seconds, meters, reps
    recorded_at = Column(DateTime, default=datetime.utcnow)

class ProgressTracking(Base):
    __tablename__ = "progress_tracking"
    
    id = Column(Integer, primary_key=True, index=True)
    athlete_id = Column(Integer, nullable=False)
    week_number = Column(Integer, nullable=False)
    sprint_100m_time = Column(Float)
    sprint_200m_time = Column(Float)
    max_squat = Column(Float)
    max_deadlift = Column(Float)
    vertical_jump = Column(Float)  # in cm
    body_weight = Column(Float)  # in kg
    recorded_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text)

# Database functions
def init_database():
    """Initialize database tables with proper error handling"""
    global _db_initialized
    
    if _db_initialized:
        return True
    
    try:
        engine, session_local = get_database_engine()
        
        # Check if database engine is available
        if engine is None or session_local is None:
            logger.warning("Database engine not available - running without database")
            return False
        
        # Create all tables with error handling
        try:
            Base.metadata.create_all(bind=engine)
        except Exception as e:
            logger.error(f"Failed to create database tables: {str(e)}")
            return False
        
        # Test database connection with a simple query
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1")).fetchone()
        except Exception as e:
            logger.error(f"Database connection test failed: {str(e)}")
            return False
        
        _db_initialized = True
        logger.info("Database initialized successfully")
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        logger.info("Application will continue without database functionality")
        return False

def get_db_session():
    """Get database session with proper error handling"""
    try:
        engine, session_local = get_database_engine()
        if session_local:
            db = session_local()
            return db
        else:
            logger.error("No database session available")
            return None
    except Exception as e:
        logger.error(f"Failed to get database session: {str(e)}")
        return None

def create_athlete(name, email, age=None, weight=None, height=None, pb_100m=None, pb_200m=None):
    """Create new athlete record"""
    db = get_db_session()
    if not db:
        logger.error("No database session available")
        return None
    
    try:
        athlete = Athlete(
            name=name,
            email=email,
            age=age,
            weight=weight,
            height=height,
            personal_best_100m=pb_100m,
            personal_best_200m=pb_200m
        )
        db.add(athlete)
        db.commit()
        db.refresh(athlete)
        return athlete
    except Exception as e:
        logger.error(f"Failed to create athlete: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def get_athlete_by_email(email):
    """Get athlete by email"""
    db = get_db_session()
    if not db:
        return None
    try:
        return db.query(Athlete).filter(Athlete.email == email).first()
    finally:
        db.close()

def get_all_athletes():
    """Get all active athletes"""
    db = get_db_session()
    if not db:
        return []
    try:
        return db.query(Athlete).filter(Athlete.is_active == True).all()
    finally:
        db.close()

def save_training_week(athlete_id, week_number, phase, notes=None):
    """Save training week data"""
    db = get_db_session()
    if not db:
        return None
    try:
        week = TrainingWeek(
            athlete_id=athlete_id,
            week_number=week_number,
            phase=phase,
            notes=notes
        )
        db.add(week)
        db.commit()
        db.refresh(week)
        return week
    except Exception as e:
        logger.error(f"Failed to save training week: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def save_training_session(week_id, day, session_type, session_data):
    """Save training session data"""
    db = get_db_session()
    if not db:
        return None
    try:
        session = TrainingSession(
            week_id=week_id,
            day_of_week=day,
            session_type=session_type,
            session_data=json.dumps(session_data)
        )
        db.add(session)
        db.commit()
        db.refresh(session)
        return session
    except Exception as e:
        logger.error(f"Failed to save training session: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def mark_session_completed(session_id, notes=None, perceived_exertion=None):
    """Mark training session as completed"""
    db = get_db_session()
    if not db:
        logger.error("No database session available")
        return None
    
    try:
        session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
        if session:
            # Update the session record
            db.query(TrainingSession).filter(TrainingSession.id == session_id).update({
                TrainingSession.completed: True,
                TrainingSession.completion_date: datetime.utcnow(),
                TrainingSession.performance_notes: notes,
                TrainingSession.perceived_exertion: perceived_exertion
            })
            db.commit()
            db.refresh(session)
        return session
    except Exception as e:
        logger.error(f"Failed to mark session completed: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def save_performance_metric(athlete_id, session_id, metric_type, value, unit):
    """Save performance metric"""
    db = get_db_session()
    if not db:
        return None
    try:
        metric = PerformanceMetrics(
            athlete_id=athlete_id,
            session_id=session_id,
            metric_type=metric_type,
            value=value,
            unit=unit
        )
        db.add(metric)
        db.commit()
        db.refresh(metric)
        return metric
    except Exception as e:
        logger.error(f"Failed to save performance metric: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def save_progress_tracking(athlete_id, week_number, **kwargs):
    """Save weekly progress tracking data"""
    db = get_db_session()
    if not db:
        return None
    try:
        progress = ProgressTracking(
            athlete_id=athlete_id,
            week_number=week_number,
            **kwargs
        )
        db.add(progress)
        db.commit()
        db.refresh(progress)
        return progress
    except Exception as e:
        logger.error(f"Failed to save progress tracking: {str(e)}")
        db.rollback()
        return None
    finally:
        db.close()

def get_athlete_progress(athlete_id):
    """Get athlete progress over time"""
    db = get_db_session()
    if not db:
        return []
    try:
        progress = db.query(ProgressTracking).filter(
            ProgressTracking.athlete_id == athlete_id
        ).order_by(ProgressTracking.week_number).all()
        return progress
    finally:
        db.close()

def get_training_history(athlete_id, limit=10):
    """Get recent training history for athlete"""
    db = get_db_session()
    if not db:
        return []
    try:
        sessions = db.query(TrainingSession).join(TrainingWeek).filter(
            TrainingWeek.athlete_id == athlete_id
        ).order_by(TrainingSession.id.desc()).limit(limit).all()
        return sessions
    finally:
        db.close()

def get_performance_analytics(athlete_id):
    """Get performance analytics for athlete"""
    db = get_db_session()
    if not db:
        return pd.DataFrame()  # Return empty DataFrame if no database
    try:
        # Get performance metrics as DataFrame for analysis
        query = f"""
        SELECT pm.*, ts.day_of_week, ts.session_type, tw.week_number, tw.phase
        FROM performance_metrics pm
        JOIN training_sessions ts ON pm.session_id = ts.id
        JOIN training_weeks tw ON ts.week_id = tw.id
        WHERE pm.athlete_id = {athlete_id}
        ORDER BY pm.recorded_at
        """
        engine, _ = get_database_engine()
        if engine:
            df = pd.read_sql(query, engine)
            return df
        return pd.DataFrame()
    except Exception as e:
        logger.error(f"Failed to get performance analytics: {str(e)}")
        return pd.DataFrame()
    finally:
        if db:
            db.close()