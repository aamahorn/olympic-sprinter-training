# This file ensures Streamlit Cloud recognizes the app entry point
# It simply imports and runs the main app
from app import main

if __name__ == "__main__":
    main()