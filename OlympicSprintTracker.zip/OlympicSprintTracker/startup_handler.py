"""
Startup handler with comprehensive error handling and graceful fallbacks.
Ensures the application starts reliably regardless of external dependencies.
"""
import os
import sys
import logging
import traceback
from typing import Optional, Tuple, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class StartupHandler:
    """Handles application startup with comprehensive error handling."""
    
    def __init__(self):
        self.startup_errors = []
        self.warnings = []
        self.database_available = False
        self.plotly_available = False
        
    def initialize_components(self) -> dict:
        """Initialize all application components with error handling."""
        results = {
            'database': self._initialize_database(),
            'plotly': self._initialize_plotly(),
            'streamlit': self._initialize_streamlit_config()
        }
        
        # Log startup summary
        self._log_startup_summary(results)
        return results
    
    def _initialize_database(self) -> dict:
        """Initialize database with fallback options."""
        try:
            # Check for DATABASE_URL
            database_url = os.getenv('DATABASE_URL')
            
            if database_url:
                # Try PostgreSQL connection
                try:
                    from database import init_database
                    success = init_database()
                    if success:
                        logger.info("PostgreSQL database initialized successfully")
                        self.database_available = True
                        return {'status': 'success', 'type': 'postgresql', 'message': 'Connected to PostgreSQL'}
                    else:
                        logger.warning("PostgreSQL initialization failed, trying SQLite fallback")
                except Exception as e:
                    logger.error(f"PostgreSQL connection failed: {str(e)}")
            
            # Try SQLite fallback
            try:
                from database import get_database_engine
                engine, session = get_database_engine()
                if engine and session:
                    logger.info("SQLite database initialized as fallback")
                    self.database_available = True
                    return {'status': 'success', 'type': 'sqlite', 'message': 'Using SQLite fallback database'}
            except Exception as e:
                logger.error(f"SQLite fallback failed: {str(e)}")
            
            # No database available
            logger.warning("No database available - running in demo mode")
            return {'status': 'demo', 'type': 'none', 'message': 'No database available - demo mode'}
            
        except Exception as e:
            error_msg = f"Database initialization failed: {str(e)}"
            logger.error(error_msg)
            self.startup_errors.append(error_msg)
            return {'status': 'error', 'type': 'none', 'message': error_msg}
    
    def _initialize_plotly(self) -> dict:
        """Initialize Plotly with error handling."""
        try:
            import plotly.graph_objects as go
            import plotly.express as px
            
            # Test basic functionality
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=[1, 2], y=[1, 2]))
            
            logger.info("Plotly initialized successfully")
            self.plotly_available = True
            return {'status': 'success', 'message': 'Plotly charts available'}
            
        except ImportError as e:
            logger.warning(f"Plotly not available: {str(e)}")
            return {'status': 'fallback', 'message': 'Using basic matplotlib fallback for charts'}
        except Exception as e:
            error_msg = f"Plotly initialization failed: {str(e)}"
            logger.error(error_msg)
            self.startup_errors.append(error_msg)
            return {'status': 'error', 'message': error_msg}
    
    def _initialize_streamlit_config(self) -> dict:
        """Ensure Streamlit configuration is properly set."""
        try:
            config_dir = '.streamlit'
            config_file = os.path.join(config_dir, 'config.toml')
            
            # Create directory if it doesn't exist
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
            
            # Check if config file exists and is properly configured
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    content = f.read()
                    if 'port = 5000' in content and 'address = "0.0.0.0"' in content:
                        logger.info("Streamlit configuration verified")
                        return {'status': 'success', 'message': 'Streamlit properly configured'}
            
            # Create or update config file
            config_content = """[server]
headless = true
address = "0.0.0.0"
port = 5000
enableCORS = false
enableXsrfProtection = false

[browser]
gatherUsageStats = false

[logger]
level = "info"
"""
            with open(config_file, 'w') as f:
                f.write(config_content)
            
            logger.info("Streamlit configuration created/updated")
            return {'status': 'success', 'message': 'Streamlit configuration updated'}
            
        except Exception as e:
            error_msg = f"Streamlit config setup failed: {str(e)}"
            logger.error(error_msg)
            self.startup_errors.append(error_msg)
            return {'status': 'error', 'message': error_msg}
    
    def _log_startup_summary(self, results: dict):
        """Log comprehensive startup summary."""
        logger.info("=== APPLICATION STARTUP SUMMARY ===")
        
        for component, result in results.items():
            status = result.get('status', 'unknown')
            message = result.get('message', 'No details available')
            logger.info(f"{component.upper()}: {status} - {message}")
        
        if self.startup_errors:
            logger.error(f"Startup completed with {len(self.startup_errors)} errors:")
            for error in self.startup_errors:
                logger.error(f"  - {error}")
        else:
            logger.info("Startup completed successfully")
        
        logger.info("=== END STARTUP SUMMARY ===")
    
    def get_status_message(self, results: dict) -> str:
        """Generate user-friendly status message."""
        if not self.startup_errors:
            if self.database_available:
                return "✅ Application ready with full database functionality"
            else:
                return "ℹ️ Application ready in demo mode (no data persistence)"
        else:
            return f"⚠️ Application started with {len(self.startup_errors)} issues - limited functionality"
    
    def handle_startup_error(self, error: Exception) -> str:
        """Handle critical startup errors with graceful degradation."""
        error_trace = traceback.format_exc()
        logger.error(f"Critical startup error: {str(error)}")
        logger.error(f"Traceback: {error_trace}")
        
        # Return user-friendly error message
        return f"Application encountered startup issues but will continue in limited mode. Error: {str(error)}"

# Global startup handler instance
startup_handler = StartupHandler()