# Olympic Sprinter Training Schedule Generator

A sophisticated web application for generating 16-week periodized training schedules for Olympic 100m/200m sprinters.

## Features

- **Periodized Training Plans**: 16-week cycles with proper volume/intensity progression
- **Energy System Training**: Speed, Speed Endurance, and Oxidative sessions
- **Complex Training**: Weight lifting + plyometrics + sprinting combinations
- **Performance Tracking**: Interactive charts for progress monitoring
- **Database Integration**: PostgreSQL for athlete data persistence
- **Comprehensive Analytics**: Performance metrics and trend analysis

## Training Session Types

1. **Speed Sessions**: Short sprints (30m, 60m) - Phosphagen system
2. **Speed Endurance**: Medium distances (150m, 250m) - Glycolytic system  
3. **Oxidative Sessions**: 30-40 minute continuous aerobic work
4. **Strength Training**: Explosive power with concentric/eccentric focus
5. **Assisted/Resistance Sprints**: Modified mechanics training
6. **Complex Training**: Multi-modal potentiation protocols

## Deployment Options

### Option 1: Streamlit Cloud
1. Push code to GitHub repository
2. Connect to Streamlit Cloud
3. Deploy with automatic HTTPS

### Option 2: Heroku
```bash
heroku create your-app-name
git push heroku main
```

### Option 3: Railway
```bash
railway login
railway new
railway deploy
```

### Option 4: Render
- Connect GitHub repository
- Auto-deploy on push

## Local Development

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Environment Variables

- `DATABASE_URL`: PostgreSQL connection string
- `PORT`: Application port (default: 5000)

## Tech Stack

- **Frontend**: Streamlit
- **Backend**: Python 3.11
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Charts**: Plotly & Matplotlib
- **Deployment**: Multi-platform support