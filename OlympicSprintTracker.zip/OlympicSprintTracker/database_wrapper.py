"""
Database wrapper with comprehensive error handling and fallback functionality.
Ensures the application works reliably regardless of database connection status.
"""

import logging
import functools
from typing import Optional, Any, Callable

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def database_operation(fallback_return=None):
    """
    Decorator for database operations that provides error handling and fallback.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                logger.error(f"Database operation {func.__name__} failed: {str(e)}")
                return fallback_return
        return wrapper
    return decorator

class DatabaseWrapper:
    """
    Wrapper class that provides safe database operations with fallback behavior.
    """
    
    def __init__(self):
        self.db_available = False
        self.db_module = None
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize database connection with proper error handling."""
        try:
            import database
            self.db_module = database
            
            # Test database initialization
            result = database.init_database()
            if result:
                self.db_available = True
                logger.info("Database initialized successfully")
            else:
                logger.warning("Database initialization returned False")
                self.db_available = False
                
        except ImportError as e:
            logger.error(f"Database module import failed: {str(e)}")
            self.db_available = False
        except Exception as e:
            logger.error(f"Database initialization failed: {str(e)}")
            self.db_available = False
    
    @property
    def is_available(self) -> bool:
        """Check if database is available."""
        return self.db_available
    
    @database_operation(fallback_return=None)
    def create_athlete(self, name: str, email: str, age=None, weight=None, height=None, pb_100m=None, pb_200m=None):
        """Create new athlete record with error handling."""
        if not self.db_available or not self.db_module:
            logger.info("Database not available, skipping athlete creation")
            return None
        
        return self.db_module.create_athlete(name, email, age, weight, height, pb_100m, pb_200m)
    
    @database_operation(fallback_return=None)
    def get_athlete_by_email(self, email: str):
        """Get athlete by email with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.get_athlete_by_email(email)
    
    @database_operation(fallback_return=[])
    def get_all_athletes(self):
        """Get all athletes with error handling."""
        if not self.db_available or not self.db_module:
            return []
        
        return self.db_module.get_all_athletes()
    
    @database_operation(fallback_return=None)
    def save_training_week(self, athlete_id: int, week_number: int, phase: str, notes=None):
        """Save training week data with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.save_training_week(athlete_id, week_number, phase, notes)
    
    @database_operation(fallback_return=None)
    def save_training_session(self, week_id: int, day: str, session_type: str, session_data: dict):
        """Save training session data with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.save_training_session(week_id, day, session_type, session_data)
    
    @database_operation(fallback_return=None)
    def mark_session_completed(self, session_id: int, notes=None, perceived_exertion=None):
        """Mark training session as completed with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.mark_session_completed(session_id, notes, perceived_exertion)
    
    @database_operation(fallback_return=None)
    def save_performance_metric(self, athlete_id: int, session_id: int, metric_type: str, value: float, unit: str):
        """Save performance metric with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.save_performance_metric(athlete_id, session_id, metric_type, value, unit)
    
    @database_operation(fallback_return=None)
    def save_progress_tracking(self, athlete_id: int, week_number: int, **kwargs):
        """Save weekly progress tracking data with error handling."""
        if not self.db_available or not self.db_module:
            return None
        
        return self.db_module.save_progress_tracking(athlete_id, week_number, **kwargs)
    
    @database_operation(fallback_return=[])
    def get_athlete_progress(self, athlete_id: int):
        """Get athlete progress over time with error handling."""
        if not self.db_available or not self.db_module:
            return []
        
        return self.db_module.get_athlete_progress(athlete_id)
    
    @database_operation(fallback_return=[])
    def get_training_history(self, athlete_id: int, limit: int = 10):
        """Get recent training history for athlete with error handling."""
        if not self.db_available or not self.db_module:
            return []
        
        return self.db_module.get_training_history(athlete_id, limit)
    
    @database_operation(fallback_return={})
    def get_performance_analytics(self, athlete_id: int):
        """Get performance analytics for athlete with error handling."""
        if not self.db_available or not self.db_module:
            return {}
        
        return self.db_module.get_performance_analytics(athlete_id)

# Create a global instance that can be imported and used
db_wrapper = DatabaseWrapper()