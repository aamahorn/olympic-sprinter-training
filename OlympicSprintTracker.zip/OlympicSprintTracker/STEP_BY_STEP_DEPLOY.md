# Get Your Short URL - Simple Steps

## What You'll Get: 
`https://olympic-sprinter.streamlit.app` (or your chosen name)

## Step 1: Create GitHub Account
- Go to **github.com**
- Sign up (free account)

## Step 2: Create Repository
1. Click **"New repository"** (green button)
2. Name: `olympic-sprinter-training`
3. Select **"Public"**
4. Click **"Create repository"**

## Step 3: Download Files from Replit
Right-click and download these files:
- `app.py`
- `pyproject.toml`
- `database.py`
- `database_wrapper.py`
- `startup_handler.py`
- `.streamlit/config.toml`
- `README.md`

## Step 4: Upload to GitHub
1. In your new repository, click **"uploading an existing file"**
2. Drag all downloaded files into the upload area
3. Scroll down and click **"Commit changes"**

## Step 5: Deploy to Streamlit Cloud
1. Go to **share.streamlit.io**
2. Click **"Sign in with GitHub"**
3. Click **"New app"**
4. Repository: Select `olympic-sprinter-training`
5. Main file path: `app.py`
6. App URL: Choose your name (e.g., `olympic-sprinter`)
7. Click **"Deploy!"**

## Result:
Your new short URL: `https://olympic-sprinter.streamlit.app`

## Time Required: 10 minutes