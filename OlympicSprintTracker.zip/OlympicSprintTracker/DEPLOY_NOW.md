# Get Your Short URL - Step by Step

## Goal: Get a clean URL like `https://sprinter-training.streamlit.app`

### Step 1: Create GitHub Account (if needed)
- Go to **github.com**
- Sign up (free)

### Step 2: Create Repository
1. Click **"New repository"** (green button)
2. Repository name: `olympic-sprinter-training`
3. Make it **Public**
4. Click **"Create repository"**

### Step 3: Upload Your Files
Download these files from your Replit workspace and upload to GitHub:

**Required Files:**
- `app.py` (main application)
- `pyproject.toml` (dependencies)
- `database.py` (database models)
- `database_wrapper.py` (error handling)
- `startup_handler.py` (startup management)
- `.streamlit/config.toml` (configuration)

**Optional Files:**
- `README.md` (documentation)
- All other `.py` files in your workspace

### Step 4: Deploy to Streamlit Cloud
1. Go to **share.streamlit.io**
2. Click **"Sign in with GitHub"**
3. Click **"New app"**
4. Select repository: `olympic-sprinter-training`
5. Main file: `app.py`
6. App name: `sprinter-training` (this becomes your URL)
7. Click **"Deploy!"**

### Step 5: Get Your Short URL
Streamlit will give you: **https://sprinter-training.streamlit.app**

## Alternative: Quick Upload Method
1. Download all files as ZIP from Replit
2. Go to your GitHub repository
3. Click **"uploading an existing file"**
4. Drag and drop all files
5. Commit changes
6. Then deploy to Streamlit Cloud

## Your New URL Will Be:
`https://[your-chosen-name].streamlit.app`

Much shorter and more professional than the long Replit URL!