#!/usr/bin/env python3
"""
Simple deployment script that can be used if Procfile deployment fails.
"""

import os
import subprocess
import sys

def main():
    # Set deployment environment variables
    os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
    os.environ['STREAMLIT_SERVER_ADDRESS'] = '0.0.0.0'
    os.environ['STREAMLIT_SERVER_ENABLE_CORS'] = 'false'
    
    # Get port from environment
    port = os.environ.get('PORT', '5000')
    
    # Run Streamlit
    cmd = [
        sys.executable, '-m', 'streamlit', 'run', 'app.py',
        '--server.port', port,
        '--server.address', '0.0.0.0',
        '--server.headless', 'true',
        '--server.enableCORS', 'false'
    ]
    
    print(f"Starting Streamlit on port {port}")
    subprocess.run(cmd)

if __name__ == '__main__':
    main()